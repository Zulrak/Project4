package ca.georgianc.on.ca;

import java.util.Random;

import org.anddev.andengine.engine.Engine;
import org.anddev.andengine.engine.camera.Camera;
import org.anddev.andengine.engine.options.EngineOptions;
import org.anddev.andengine.engine.options.EngineOptions.ScreenOrientation;
import org.anddev.andengine.engine.options.resolutionpolicy.RatioResolutionPolicy;
import org.anddev.andengine.entity.modifier.AlphaModifier;
import org.anddev.andengine.entity.modifier.MoveModifier;
import org.anddev.andengine.entity.modifier.SequenceEntityModifier;
import org.anddev.andengine.entity.scene.Scene;
import org.anddev.andengine.entity.sprite.Sprite;
import org.anddev.andengine.entity.util.FPSLogger;
import org.anddev.andengine.opengl.texture.Texture;
import org.anddev.andengine.opengl.texture.TextureOptions;
import org.anddev.andengine.opengl.texture.region.TextureRegion;
import org.anddev.andengine.opengl.texture.region.TextureRegionFactory;
import org.anddev.andengine.ui.activity.BaseGameActivity;

import android.os.Handler;
public class PlayGame extends BaseGameActivity {
	// ===========================================================
	// Constants
	// ===========================================================

	private static final int CAMERA_WIDTH = 480;
	private static final int CAMERA_HEIGHT = 320;

	// ===========================================================
	// Fields
	// ===========================================================

	private Handler mHandler;
	
	protected Camera mCamera;

	protected Scene mMainScene;

	private Texture mGameBackTexture;
	private Texture mRockTexture;
	private TextureRegion mGameBackTextureRegion;
	private TextureRegion mRockTextureRegion;
	private Sprite[] asprrock = new Sprite[10];
	private int nrock;
	Random gen;

	@Override
	public Engine onLoadEngine() {
		mHandler = new Handler();
		gen = new Random();
		this.mCamera = new Camera(0, 0, CAMERA_WIDTH, CAMERA_HEIGHT);
		return new Engine(new EngineOptions(true, ScreenOrientation.LANDSCAPE, new RatioResolutionPolicy(CAMERA_WIDTH, CAMERA_HEIGHT), this.mCamera));
	}

	@Override
	public void onLoadResources() {
		/* Load Textures. */
		TextureRegionFactory.setAssetBasePath("gfx/Game/");
		mGameBackTexture = new Texture(512, 512, TextureOptions.BILINEAR_PREMULTIPLYALPHA);
		mGameBackTextureRegion = TextureRegionFactory.createFromAsset(this.mGameBackTexture, this, "backgroundGame.jpg", 0, 0);
		mEngine.getTextureManager().loadTexture(this.mGameBackTexture);
		
		mRockTexture = new Texture(512, 256, TextureOptions.DEFAULT);
		mRockTextureRegion = TextureRegionFactory.createFromAsset(this.mRockTexture, this, "rock.jpg", 0, 0);
		mEngine.getTextureManager().loadTexture(this.mRockTexture);
		
	}
	
	@Override
	public Scene onLoadScene() {
		this.mEngine.registerUpdateHandler(new FPSLogger());

		final Scene scene = new Scene(1);

		/* Center the camera. */
		final int centerX = (CAMERA_WIDTH - mGameBackTextureRegion.getWidth()) / 2;
		final int centerY = (CAMERA_HEIGHT - mGameBackTextureRegion.getHeight()) / 2;

		/* Create the sprites and add them to the scene. */
		final Sprite background = new Sprite(centerX, centerY, mGameBackTextureRegion);
		scene.getLastChild().attachChild(background);
		
		
       //create the rocks 
       	nrock = 0;
		mHandler.postDelayed(mStartrock,2000);
		return scene;
	}

	@Override
	public void onLoadComplete() {
	}
	
    private Runnable mStartrock = new Runnable() {
        public void run() {
        	int i = nrock++;
        	Scene scene = PlayGame.this.mEngine.getScene();
           	float startY = gen.nextFloat()*(CAMERA_HEIGHT - 50.0f);
           	asprrock[i] = new Sprite(CAMERA_WIDTH - 30.0f, startY, mRockTextureRegion.clone());
           	asprrock[i].registerEntityModifier(
           			new SequenceEntityModifier (
           						new AlphaModifier(5.0f, 0.0f, 1.0f),
          						new MoveModifier(80.0f, asprrock[i].getX(), 60.0f, 
         							asprrock[i].getY(), (float)CAMERA_HEIGHT/2)));
           	scene.getLastChild().attachChild(asprrock[i]);
        	if (nrock < 10){
        		mHandler.postDelayed(mStartrock,2000);
        	}
        }
     };
}
